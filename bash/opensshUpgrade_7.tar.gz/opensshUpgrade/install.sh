#!/bin/bash
parent_path=/root/localrepo
cd ""
mkdir -p ./ssh_bak/pam.d ./ssh_bak/system ./ssh_bak/config ./ssh_bak/sysconfig
/bin/cp -rpf /etc/pam.d/ssh* ./ssh_bak/pam.d/
/bin/cp -rpf /etc/ssh/* ./ssh_bak/config/
/bin/cp -rpf /lib/systemd/system/sshd* ./ssh_bak/system/
/bin/cp -rpf /etc/sysconfig/sshd ./ssh_bak/sysconfig/

#mkdir -p /etc/yum.repos.d/backup
#mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/backup
rm -rf /tmp/localrepo
mkdir -p /tmp/localrepo
cp -rf ./localrepo/* /tmp/localrepo
cat > /etc/yum.repos.d/localrepo.repo <<EOF
[localrepo]
name=Local Repository
baseurl=file:///tmp/localrepo
gpgcheck=0
enabled=1
EOF

#yum clean all
#yum -y install openssl
yum -y install openssh-server --disablerepo="*" --enablerepo="localrepo"
rm -rf /tmp/localrepo
rm -f /etc/yum.repos.d/localrepo.repo
#mv /etc/yum.repos.d/backup/*.repo /etc/yum.repos.d
#rm -rf /etc/yum.repos.d/backup

# restore configarations
/bin/cp -pf ./ssh_bak/pam.d/* /etc/pam.d/
#/bin/cp -pf ./ssh_bak/system/* /lib/systemd/system/
/bin/cp -pf ./ssh_bak/config/* /etc/ssh/
/bin/cp -pf ./ssh_bak/sysconfig/* /etc/sysconfig/
chmod 600 /etc/ssh/ssh_host_*_key

# modify /etc/ssh/sshd_config
#cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak

# copy ssh-copy-id
cp ssh-copy-id /usr/bin
chmod 755 /usr/bin/ssh-copy-id
systemctl restart sshd
systemctl enable sshd
systemctl status sshd
rpm -qa | grep open
systemctl status sshd| grep "Active: active (running)"

if [ 0 -eq 0 ]; then
    echo -e "\033[32m[INFO] OpenSSH upgraded to 8.1p1 successfully ! \033[0m"
else
    echo -e "\033[31m[ERROR] OpenSSH upgraded to 8.1p1 faild ! \033[0m"
fi
